# <div align="center">软件分享</div>
  <span id='date'>2024-03-14</span>
  <span class='key-tag'>分享</span><span class='key-tag'>软件</span>
  - - -
  

## 安卓常用
<div class='share-soft'><div class='soft-item item'>
          <div class='flex'>
            <a stars='4'>今日头条</a>
            <div class='title-after'>⭐⭐⭐</div>
          </div>
          <div class='soft-detail'>
            <div class='soft-info'>
            <span id="date" >2023-09-11</span>
            <span id="version" >5.15.0</span>
            <div class='soft-tag'>
              <span class='tag'>新闻</span><span class='tag'>视频</span><span class='tag'>安卓</span>
            </div>
          </div>
          <div class='info'>
            查看新闻视频
          </div>
          <div class='dl flex'>
            <span to='https://www.lanzouq.com/i7LRV180sotg'>谷歌版8.1.7</span>
          </div>
          </div>
        </div>
      </div>

## 工具
<div class='share-soft'><div class='soft-item item'>
          <div class='flex'>
            <a stars='4'>格式工厂</a>
            <div class='title-after'>⭐⭐⭐⭐</div>
          </div>
          <div class='soft-detail'>
            <div class='soft-info'>
            <span id="date" >2023-08-10</span>
            <span id="version" >5.15.0</span>
            <div class='soft-tag'>
              <span class='tag'>视频</span><span class='tag'>音频</span><span class='tag'>图片</span>
            </div>
          </div>
          <div class='info'>
            一款视频、图片、音频的转换、压制、修改软件
          </div>
          <div class='dl flex'>
            <span to='http://formatfactory.org/CN/index.html'>官网</span><div class='decrypt undecrypt' jmType='html' value='U2FsdGVkX19gFnHfxtnifdzXJnHlAoRUxGrY3xpYhEmzqJCUXLr1YEnXI7rCUTVWFW70LAaP1Z4xbH+5pkOR/rXd2Sy8Y/vSORguqE9+BcA='><span>网盘</span></div>
          </div>
          </div>
        </div>
      <div class='soft-item item'>
          <div class='flex'>
            <a stars='4'>HEU KMS Activator </a>
            <div class='title-after'>⭐⭐⭐⭐⭐</div>
          </div>
          <div class='soft-detail'>
            <div class='soft-info'>
            <span id="date" >2023-08-10</span>
            <span id="version" >5.15.0</span>
            <div class='soft-tag'>
              <span class='tag'>windows</span><span class='tag'>office</span><span class='tag'>激活</span>
            </div>
          </div>
          <div class='info'>
            一款windows、office状态查询、激活工具
          </div>
          <div class='dl flex'>
            <div class='decrypt undecrypt' jmType='html' value='U2FsdGVkX19TWBQpE1hL3e4r5acH2baTi6knOdgWPAm6u47dd2mqni5VRgEJuVqv3dpFYIb615zQTwquJPbUNVL9wvyQa2jO1SA7Us7YIdY='><span>网盘</span></div>
          </div>
          </div>
        </div>
      </div>