# <div align="center">网站分享</div>

<span id='date'>2024-03-14</span>
<span class='key-tag'>web</span><span class='key-tag'>分享</span>
- - -

## 导航
- [龙轩导航](http://ilxdh.com/)
- [影视导航](https://ys.urlsdh.com/)
- [迷鹿导航](https://404l.com/)
## 视频
- [厂长](https://www.cz01.vip/)
## 工具
- [特殊符号](https://cn.symbolslist.com/)
- [squoosh](http://squoosh.cn/)  （图片压缩转换）
- [LaTeX编辑器](https://www.latexlive.com/##)
## 杂项
- [Chrome扩展](https://crxdl.com/)
- [y8](https://zh.y8.com/) （浏览器小游戏）
## 软件
-  [kdenlive](https://kdenlive.org/zh/ )（开源视频编辑软件）
- [殁漂遥](https://www.mpyit.com/)  （合集）
- [423](https://www.423down.com/)  （合集）
- [果核剥壳](https://www.ghxi.com/)  （合集）
- [懒得勤快](https://ldqk.xyz/)（合集）
## 小说
- [笔趣阁](http://www.biquge5200.cc/)
## 资源
- [压盘](https://yapan.io/)  （网盘搜索）
- [UP云搜](https://www.upyunso.com/ ) （网盘搜索）
- [GBT乐赏游戏空间](http://gbtgame.ysepan.com/)  （游戏资源）
- [flysheep资源避难所](http://flysheep.ysepan.com/) （游戏资源）
- [叽哩游戏](https://www.jiligamefun.com/)（游戏资源）
- [Jay仓库](https://www.likejay.cn/) （导航）
- [优品PPT](https://www.ypppt.com/)  （PPT模板）
- [阿虚同学](https://axutongxue.com/)  （网站资源）
- [图欧学习导航](https://tuostudy.upnb.top/)
- [磁力猫](http://clm.la/) （磁力搜索）
- [阿里云资源分享](https://link3.cc/4kzy)
- [备胎书屋](https://beitai.cc/)  （精校小说）
- [知轩藏书](https://zxcs.zip/) （精校小说）
## github
- [我的电视](https://github.com/lizongying/my-tv) (直播)